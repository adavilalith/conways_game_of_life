#include <stdio.h>

typedef struct{
	int radius;
}circle;

typedef struct{
	int side;
}sqr;

typedef struct{
	int length;
	int bredth;
}rect;


typedef union{
	circle c;
	sqr s;
	rect r;
}shape;

void circleArea(shape *x){
	printf("area:%f\n",x->c.radius*x->c.radius*3.12159);
}
void rectangleArea(shape *x){
	printf("area:%d\n",x->r.length*x->r.bredth);
}
void squareArea(shape *x){
	printf("area:%d\n",x->s.side*x->s.side);
}

int main(){
	shape a={.c.radius=5};
	circleArea(&a);
	shape b={.s.side=5};
	squareArea(&b);
	shape c={.r.length=2,.r.bredth=3};
	rectangleArea(&c);
	return 0;

}
