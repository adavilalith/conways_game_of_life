#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct seat{
	char name[20];
	struct seat* next;
};

typedef struct seat seat;

seat* createSeating(char *names[],int n){
	seat *head=NULL,*temp;
	for(int i=0;i<n;i++){
		seat* t=(seat*)malloc(sizeof(seat));
		strcpy(names[i],t->name);
		t->next=NULL;
		if(head==NULL){
			head=t;
			temp=head;
		}
		else{
			temp->next=t;
			temp=temp->next;
		}
	}
	return head;
}


int mai(){
	char *names[1]={"a","b","c","d"};
	seat* ll=createSeating(names,4);
	return 0;
}
