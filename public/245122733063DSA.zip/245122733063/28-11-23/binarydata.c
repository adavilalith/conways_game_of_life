#include<stdio.h>

typedef struct{
	unsigned int b0:1;
	unsigned int b1:1;
	unsigned int b2:1;
	unsigned int b3:1;
}bindata;

int main(){
	int decinum;
	bindata data;
	printf("enter number(0-15):");
	scanf("%d",&decinum);
	data.b0=decinum%2;
	decinum/=2;
	data.b1=decinum%2;
	decinum/=2;
	data.b2=decinum%2;
	decinum/=2;
	data.b3=decinum%2;
	decinum/=2;

	printf("%u %u %u %u \n",data.b3,data.b2,data.b1,data.b0);
	return 0;
}
