#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct person{
	char name[20];
	struct person *father;
	struct person *mother;
};

typedef struct person person;

person* createPerson(char *name,person* father,person* mother){
	person* x=(person*)malloc(sizeof(person));
	strcpy(x->name,name);
	x->father=father;
	x->mother=mother;
	return x;
};

void printPerson(person* x){
	printf("name:%s\n",x->name);
	if(x->father)printf("father:%s\n",x->father->name);
	if(x->mother)printf("mother:%s\n",x->mother->name);
}

int main(){
	person *a,*b,*c;
	a=createPerson("a",NULL,NULL);
	b=createPerson("b",NULL,NULL);
	c=createPerson("c",a,b);
	printPerson(c);
	return 0;
}
