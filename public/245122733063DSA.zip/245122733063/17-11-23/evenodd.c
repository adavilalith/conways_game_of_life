//program to cehck whether number is even or odd
#include<stdio.h>


int main(){
	int num;
	printf("enter a number:");
	scanf("%d",&num);
	if(num%2){
		printf("%d is odd\n",num);
	}
	else{
		printf("%d is even\n",num);
	}
	
}
