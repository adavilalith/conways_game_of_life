//program to matain student records with fieds
// student name,student roll number, student GPA
// read and display data
#include<stdio.h>
#include<string.h>
typedef struct{
	char name[100];
	long int rollno;
	float gpa;
}student;
void updateStudent(student* obj){
	printf("enter student name:");
	scanf("%s",obj->name);
	printf("enter student roll number:");
	scanf("%ld",&(obj->rollno));
	printf("enter student GPA:");
	scanf("%f",&(obj->gpa));
}
void displayStudent(student obj){
	printf("student name:%s\n",obj.name);
	printf("student roll number:%ld\n",obj.rollno);
	printf("student name:%.2f\n",obj.gpa);
}
int main(){
	student cseA[3];
	for(int i=0;i<3;i++){
		updateStudent(&cseA[i]);
	}
	for(int i=0;i<3;i++){
		displayStudent(cseA[i]);
	}
	return 0;
}
