//program to demo call by value and call by reference by using swap func
#include<stdio.h>

void swap1(int a,int b){
	int temp=a;
	a=b;
	b=temp;
}
void swap2(int* a,int* b){
	int temp=*a;
	*a=*b;
	*b=temp;
}

int main(){
	int a,b;
	printf("enter two numbers:");
	scanf("%d %d",&a,&b);
	printf("before swap1\n");
	printf("a=%d,b=%d\n",a,b);
	swap1(a,b);
	printf("after swap1\n");
	printf("a=%d,b=%d\n",a,b);
	printf("before swap2\n");
	printf("a=%d,b=%d\n",a,b);
	swap2(&a,&b);
	printf("after swap2\n");
	printf("a=%d,b=%d\n",a,b);
	return 0;
}
