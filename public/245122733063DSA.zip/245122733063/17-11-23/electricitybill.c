//program to calculate electricity bill
#include<stdio.h>

int main(){
	int units;
	printf("enter units comsumed:");
	scanf("%d",&units);
	float bill=0;
	if(units<=50){
		bill+=0.5*units;
	}
	else if(units>50 && units<=150){
		bill+=0.5*50+0.75*(units-50);
	}
	else if(units>150 && units<=250){
 		bill+=0.5*50+0.75*100+1.20*(units-150);
	}
	else{
		bill+=0.5*50+0.75*100+1.20*(100)+1.5*(units-250);
	}
	if(bill>300){
		bill+=0.15*bill;
	}
	printf("amount:%.2f\n",bill);
	return 0;
}
