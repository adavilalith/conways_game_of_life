//program to check if a number is a palindrome number or not
#include<stdio.h>

int main(){
	int num;
	printf("enter a number:");
	scanf("%d",&num);
	int n=0;
	int digits[1000];
	int i=0;
	while(num>0){
		digits[i]=num%10;
		num/=10;
		i++;
		n++;
	}
	int j=i-1,flag=1;
	i=0;
	while(i<=j){
		if(digits[i]!=digits[j]){
			flag=0;
			break;
		}
		i++;
		j--;
	}
	if(flag){
		printf("palindrome\n");
	}
	else{
		printf("not palindrome\n");
	}
	return 0;
}
