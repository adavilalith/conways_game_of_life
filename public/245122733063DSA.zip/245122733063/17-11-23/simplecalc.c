//wap to implement simple calculator
#include<stdio.h>

int main(){
	int a,b,c;
	printf("enter number 1:");
	scanf("%d",&a);
	printf("enter number 2:");
	scanf("%d",&b);
	printf("1:addition\n2:subtraction\n3:multiplication\n4:division\n5:modulo\nenter your choice:");
	scanf("%d",&c);
	switch(c){
		case 1:
			printf("%d+%d=%d",a,b,a+b);
			break;
		case 2:
			printf("%d-%d=%d",a,b,a-b);
			break;
		case 3:
			printf("%dx%d=%d",a,b,a*b);
			break;
		case 4:
			printf("%d/%d=%lf",a,b,a/(b*1.0) );
			break;
		case 5:
			printf("%d modulo %d=%d",a,b,a%b);
			break;
		default:
			printf("invalid operation\n");
	}
	printf("\n");
	return 0;
}
