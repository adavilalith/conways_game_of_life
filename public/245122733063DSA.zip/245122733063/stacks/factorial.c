#include<stdio.h>



#define true 1
#define false 0
#define size 10

long int s[size],top=-1;

void push(long int num){
	if(top==size-1){
		printf("STACK OVERFLOW\n");
	}
	else{
		top++;
		s[top]=num;
	}
}


long int pop(){
	if(top==-1){
		printf("STACK UNDERFLOW\n");
		return -1;
	}
	else{
		return s[top--];
	}
}
long int factorial(int num){
	push(1);
	for(int i=2;i<=num;i++){
		push(pop()*i);
	}
	return s[top];
}
int main(){
	int num;
	printf("enter a number:");
	scanf("%d",&num);
	printf("factorial:%ld\n",factorial(num));
	return 0;	
}
