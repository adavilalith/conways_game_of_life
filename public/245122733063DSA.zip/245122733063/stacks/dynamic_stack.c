#include<stdio.h>
#include<stdlib.h>


int size;

int* s,top=-1;
void push(int num){
	if(isFull()){
		size*=2;
		s=(int*)realloc(s,sizeof(int)*size);
	}
	top++;
	s[top]=num;
	printf("%d is pushed to top of stack\n",num);
	
}

int isFull(){
	if(top==size-1){
		return 1;
	}
	else{
		return 0;
	}
}

int pop(){
	if(isEmpty()){
		printf("STACK UNDERFLOW\n");
		return -1;
	}
	else{
		return s[top--];
	}
}

int isEmpty(){
	if(top<0){
		return 1;
	}
	else{
		return 0;
	}
}

int peek(){
	if(isEmpty()){
		printf("Stack is empty\n");
		return -1;
	}
	else{
		return s[top];
	}
}

void display(){
	if(isEmpty()){
		printf("Stack is empty\n");
	}
	else{
		for(int i=0;i<=top;i++){
			printf("%d ",s[i]);
		}
		printf("\n");
	}
}
int main(){
	printf("enter stack size:");
	scanf("%d",&size);
	s=(int*)malloc(size*sizeof(int));
	printf("MENU\n1:push\n2:pop\n3:peek\n4:display\nctrl^C to exit\n");
	while (1){
		int ch;
		int val;
		scanf("%d",&ch);
		switch(ch){
			case 1:
				val;
				printf("enter element:");
				scanf("%d",&val);
				push(val);
				break;
			case 2:
				val=pop();
				printf("%d was popped from the stack\n",val);
				break;
			case 3:
				val=peek();
				printf("%d is the top element of  the stack\n",val);
				break;
			case 4:
				display();
				break;
			default:
				printf("invalid case\n");
				break;
		}
	}
	return 0;
}






