#include<stdio.h>
#include <math.h>


#define true 1
#define false 0
#define size 30

float s[size];
int top=-1;

void push(float num){
	if(top==size-1){
		printf("push STACK OVERFLOW\n");
	}
	else{
		top++;
		s[top]=num;
	}
}


float pop(){
	if(top<0){
		printf("pop STACK UNDERFLOW\n");
		return -1;
	}
	else{
		return s[top--];
	}
}

int main(){
	char postfix[30];
	printf("enter postfix expression:");
	scanf("%[^\n]s",postfix);
	for(int i=0;postfix[i]!='\0';i++){
		if(postfix[i]>=48 && postfix[i]<=57){
			push(postfix[i]-48);
		}
		else{
			float p1,p2;
			p2=pop();
			p1=pop();
			char ch=postfix[i];
			switch(ch){
				case '+':
					push(p1+p2);
					break;
				case '-':
					push(p1-p2);
					break;
				case '*':
					push(p1*p2);
					break;
				case '/':
					push(p1/p2);
					break;
				case '^':
					push(pow(p1,p2));
					break;
			}
		}
	}
	printf("ans:%f\n",s[0]);
	return 0;
}

