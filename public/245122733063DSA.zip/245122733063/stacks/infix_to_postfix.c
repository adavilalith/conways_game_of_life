#include<stdio.h>



#define true 1
#define false 0
#define size 30

char s[size],top=-1;

void push(char num){
	if(top==size-1){
		printf("push STACK OVERFLOW\n");
	}
	else{
		top++;
		s[top]=num;
	}
}


char pop(){
	if(top<0){
		printf("pop STACK UNDERFLOW\n");
		return -1;
	}
	else{
		return s[top--];
	}
}

int precedence(char ch){
	switch(ch){
		case '^':
			return 5;
		case '/':
			return 4;
		case '*':
			return 4;
		case '+':
			return 3;
		case '-':
			return 3;
		default:
			return 0;
	}
}

int main(){
	char infix[30];
	printf("enter expression:");
      	scanf("%[^\n]s",infix);
	for(int i=0;infix[i]!='\0';i++){
		if((infix[i]>=48 && infix[i]<=57)||(infix[i]>=65 &&infix[i]<=90)){	
			printf("%c",infix[i]);
		}
		else{
			char ch=infix[i];
			switch(ch){
				case '(':
					push(ch);
					break;
				case ')':
					while(s[top]!='('){
						if(top==-1)break;
						printf("%c",pop());
					}
					pop();
					break;
				default:
					if(top==-1){
						push(ch);
					}
					else{
						while(precedence(s[top])>=precedence(ch)){
							if(top==-1)break;
							printf("%c",pop());
						}
						push(ch);
					}
					break;
			}
		}
	}
	while(top!=-1){
		printf("%c",pop());
	}
	return 0;
}






