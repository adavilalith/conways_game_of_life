#include<stdio.h>
#include<stdlib.h>
#define MAX 30
int queue[MAX],rear=-1,front=-1;
void enqueue(int);
int dequeue();
int rearele();
int frontele();
int isEmpty();
int isFull();
void display();

int main(){
	int ch,val;
	printf("MENU\n1:Insert\n2:Delete\n3:rear element\n4:front element\n5:display\nctrl^c to exit\n");
	while(1){
		scanf("%d",&ch);
		switch(ch){
			case 1:
				printf("enter number:");
				scanf("%d",&val);
				enqueue(val);
				break;		
			case 2:
				val=dequeue();
				if(val==-1){
					printf("error\n");
					continue;
				}
				printf("%d is the element deleted\n",val);
				break;
			case 3:
				val=rearele();
				if(val==-1){
					printf("error\n");
					continue;
				}
				printf("%d is the rear element\n",val);
				break;
			case 4:
				val=frontele();
				if(val==-1){
					printf("error\n");
					continue;
				}
				printf("%d is the front element\n",val);
				break;
			case 5:
				display();
				break;
			default:
				printf("invalid choice\n");
				break;
		}
	}
}

int isFull(){
	if(rear==MAX-1){
		return 1;
	}
	else{
		return 0;
	}
}
int isEmpty(){
	if(front==rear){
		return 1;
	}
	else{
		return 0;
	}
}
void enqueue(int val){
	if(isFull()){
		printf("Queue is full\n");
		return;
	}
	else{
		rear++;
		queue[rear]=val;
		printf("%d inserted into queue\n",val);	
	}
}
int dequeue(){
	if(isEmpty()){
		printf("Queue is empty\n");
		return -1;
	}
	else{
		return queue[++front];
	}
}

int frontele(){
	if(isEmpty()){
		return -1;
	}
	return queue[front+1];
}
int rearele(){
	if(isEmpty()){
		return -1;
	}
	return queue[rear];
}


void display(){
	for(int i=front+1;i<=rear;i++){
		printf("%d ",queue[i]); 
	}	
	printf("\n");
}
