#include<stdio.h>
#include<stdlib.h>
#define CAP 10
int dq[CAP],f=-1,r=-1,cap=CAP;
void frontenqueue();
void rearenqueue();
int frontdequeue();
int reardequeue();
int frontele();
int rearele();
void display();

int main(){
	int ch;
	printf("MENU\n1:insert at front\n2:insert at rear\n3:delete at front\n4:delete at rear\n5:front element\n6:rear element\n7:display\n");
	while(1){
		scanf("%d",&ch);
		switch(ch){
			case(1):
				frontenqueue();
				break;
			case(2):
				rearenqueue();
				break;
			case(3):
				frontdequeue();
				break;
			case(4):
				reardequeue();
				break;
			case(5):
				frontele();
				break;
			case(6):
				rearele();
				break;
			case(7):
				display();
				break;
			default:
				printf("invalid input\n");
				break;
		}
	}
	return 0;
}
void frontenqueue(){
	if((f==-1)&&(r==cap-1)){
		printf("queue is full\n");
		return;
	}
	int val;
	printf("enter element:");
	scanf("%d",&val);	
	if((f==-1)&&(r!=cap-1)){
		for(int i=r;i>f;i--){
			dq[i+1]=dq[i];
		}
		dq[f+1]=val;
		r++;
	}
	else{
		dq[f+1]=val;
		f--;
	}
	
}


void rearenqueue(){
	if((f==-1)&&(r==cap-1)){
		printf("queue is full\n");
		return;
	}
	int val;
	printf("enter element:");
	scanf("%d",&val);	
	if(r==cap-1){
		for(int i=f;i<=r;i++){
			dq[i]=dq[i+1];
		}
		dq[r]=val;
		f--;
	}
	else{
		dq[++r]=val;
	}
}
	
int frontdequeue(){
	if(f==r){
		printf("queue is empty\n");
		return -1;	
	}
	else{
		printf("%d is deleted from queue\n",dq[++f]);
		return dq[f];
	}
}
int reardequeue(){
	if(f==r){
		printf("queue is empty\n");
		return -1;	
	}
	else{
		printf("%d is deleted from queue\n",dq[r]);
		return dq[r--];
	}
}
int frontele(){
	if(f==r){
		printf("queue is empty\n");
		return -1;	
	}
	else{
		printf("%d is the front element\n",dq[f+1]);
		return dq[f+1];
	}
}
int rearele(){
	if(f==r){
		printf("queue is empty\n");
		return -1;	
	}
	else{
		printf("%d is the front element\n",dq[r]);
		return dq[r];
	}
}
void display(){
	if(f==r){
		printf("queue is empty\n");
	}
	else{
		for(int i=f+1;i<=r;i++){
			printf("%d,",dq[i]);
		}
		printf("\n");
	}
}



