#include <stdio.h>
#include<stdlib.h>
int *queue,f,r,cap=3;
void enqueue();
int dequeue();
int frontele();
int rearele();
int isFull();
int isEmpty();
void display();

int main(){
	queue=(int*)malloc(cap*sizeof(int));
	int ch,val;
	printf("MENU\n1:insert\n2:delete\n3:front element\n4:rear element\5:display\nctrl^c to exit\n");
	while(1){
		scanf("%d",&ch);
		switch(ch){
			case(1):
				enqueue();
				break;		
			case(2):
				dequeue();
				break;		
			case(3):
				frontele();
				break;		
			case(4):
				rearele();
				break;		
			case(5):
				display();
				break;		
			default:
				printf("invalid input\n");
				break;
		
		}
	}
	return 0;
}

int isFull(){
	if((r+1)%cap==f){
		return 1;
	}
	else{
		return 0;
	}
}

void enqueue(){
	if(isFull()){
		int *temp,start,i,j=1;
		temp=(int*)malloc(cap*2*sizeof(int));
		start=(f+1)%cap;
		if(start<2){
			for(i=start;i<=cap-1;i++){
				temp[j++]=queue[i];
			}
		}
		else{
			for(i=start;i<cap;i++){
				temp[j++]=queue[i];
			}
			for(i=0;i<r;i++){
				temp[j++]=queue[i];
			}
		}
		f=0;
		r=cap-1;
		cap*=2;
		queue=temp;

	}
	
		int val;
		printf("enter element:");
		scanf("%d",&val);
		r=(r+1)%cap;
		queue[r]=val;

}

int isEmpty(){
	if(f==r){
		return 1;
	}
	else{
		return 0;
	}
}

int dequeue(){
	int val;
	if(isEmpty()){
		printf("queue is empty\n");
		return -1;
	}
	else{
		f=(f+1)%cap;
		val=queue[f];
		printf("%d was deleted from queue\n",val);
		return val;
	}
}

int frontele(){
	int val;
	if(isEmpty()){
		printf("queue is empty\n");
		return -1;
	}
	else{
		f=(f+1)%cap;
		val=queue[f];
		printf("%d is the front element\n",val);
		return val;
	}
}

int rearele(){
	int val;
	if(isEmpty()){
		printf("queue is empty\n");
		return -1;
	}
	else{

		val=queue[r];
		printf("%d is the rear element\n",val);
		return val;
	}
}

void display(){
	if(isEmpty()){
		printf("Queue is empty\n");
	}
	else{	
		int start=(f+1)%cap;
		for(int i=start;i!=(r+1)%cap;i=(i+1)%cap){
			printf("%d,",queue[i]);
		}
		printf("\n");	
	}
}
