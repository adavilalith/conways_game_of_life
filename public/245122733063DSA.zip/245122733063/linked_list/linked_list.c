#include<stdio.h>
#include<stdlib.h>

struct node{
	int val;
	struct node* next;
};

typedef struct node node;

node* head=NULL;

void display(){
	node *temp=head;
	while(temp!=NULL){
		printf("%d->",temp->val);
		temp=temp->next;
	}
	printf("NULL\n");
}

void beginInsert(int val){
	node* t=(node*)malloc(sizeof(node));
	t->val=val;
	t->next=NULL;
	if(head==NULL){
		head=t;
		return;
	}
	else{
		t->next=head;
		head=t;
		return;
	}
}

void endInsert(int val){
	node* t=(node*)malloc(sizeof(node));
	t->val=val;
	t->next=NULL;
	if(head==NULL){
		head=t;
		return;
	}
	node* temp=head;
	while(temp->next!=NULL){
		temp=temp->next;
	}
	temp->next=t;
}

//0 based positions
void insert(int val,int pos){
	int i=0;
	node* t=(node*)malloc(sizeof(node));
	t->val=val;
	t->next=NULL;
	if(head==NULL){
		head=t;
		return;
	}
	node *temp=head;
	for(int i=0;i<pos-1;i++){
		if(temp==NULL){
			printf("position out of bounds\n");
			return;
		}
		temp=temp->next;		
	}
	t->next=temp->next;
	temp->next=t;
}

void beginDelete(){
	if(head==NULL){
		printf("linked list is empty\n");
	}
	else{
		node* t=head;
		head=head->next;
		free(t);
	}
}

void endDelete(){
	if(head==NULL){
		printf("linked list is empty\n");
	}
	else if(head->next==NULL){
		free(head);
		head=NULL;
	}
	else{
		node* temp=head;
		while(temp->next->next!=NULL){
			temp=temp->next;
		}
		free(temp->next);
		temp->next=NULL;
	}
}

void delete(int pos){
	if(head==NULL){
		printf("linked list is empty\n");	
	}
	else{
		if(pos==0){
			node *t=head;
			head=head->next;
			free(t);
			return;
		}
		node *temp=head;
		for(int i=0;i<pos-1;i++){
			if(temp==NULL){
				printf("position out of bounds\n");
				return;
			}
			temp=temp->next;
		}
		node* t=temp->next;
		temp->next=temp->next->next;
		free(t);
	}
}

void reverse(){
	node *curr=head,*prev=NULL,*nextNode=NULL;
	while(curr!=NULL){
		nextNode=curr->next;
		curr->next=prev;
		prev=curr;
		curr=nextNode;
	}
	head=prev;
}


int search(int val){
	node *temp=head;
	int i=0;
	while(temp!=NULL){
		if(temp->val==val){
			printf("%d as position %d\n",val,i);
			return i;
		}
		temp=temp->next;
		i++;
	}
	printf("%d not in linked list\n",val);
	return -1;
}

int main(){
	endInsert(1);
	display();
	endInsert(2);
	display();
	endInsert(3);
	display();
	insert(4,1);
	display();
	reverse();
	display();
	search(4);
	search(2);
}


