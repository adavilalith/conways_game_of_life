#include <stdio.h>
#include <math.h>
typedef struct{
	float x;
	float y;
} point;


int main(){
	point p1,p2;
	printf("enter x and y coordinates of point 1:");
	scanf("%f %f",&p1.x,&p1.y);
	printf("enter x and y coordinates of point 2:");
	scanf("%f %f",&p2.x,&p2.y);
	float dist=sqrt(pow((p1.x-p2.x),2)+pow((p1.y-p2.y),2));	
	printf("distace:%f\n",dist);
	return 0;
}
