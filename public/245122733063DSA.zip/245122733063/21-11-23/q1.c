#include<stdio.h>

enum Month{
	January,February,March,April,May,June,July,August,September,October,November,December
};

enum Day{
	First=1,Second,Third,Fourth,Fifth,Sixth,Seventh,Eighth,Ninth,Tenth,
		Eleventh,Twelfth,Thirteenth,Fourteenth,Fifteenth,Sixteenth,Seventeenth,Eighteenth,Nineteenth,Twenieth,

	TwentyFirst,TwentySecond,TwentyThird,TwentyFourth,TwentyFifth,TwentySixth,TwentySeventh,TwentyEighth,TwentyNineth,Thirtieth,ThirtyFirst
};

int dayInMonth(enum Month month){
	if(month==February){
	return 28;
	}
	else if(month==April||month==June||month==June||month==November){
		return 30;
	}
	else{
		return 31;
	}
}


void printTomorrowDate(enum Month todayMonth,enum Day todayDay){
	int days=dayInMonth(todayMonth);

	if(todayDay==days){
		todayDay=First;
		todayMonth=(todayMonth+1)%12;
		printf("Tomorrow's Date: %dst %s\n",todayDay,
			(todayMonth==January)?"January":
			(todayMonth==February)?"February":
			(todayMonth==March)?"March":
			(todayMonth==April)?"Apri":
			(todayMonth==May)?"May":
			(todayMonth==June)?"June":
			(todayMonth==July)?"July":
			(todayMonth==August)?"August":
			(todayMonth==September)?"September":
			(todayMonth==October)?"October":
			(todayMonth==November)?"November":
			"December");
	}
	else{
		todayDay++;
		printf("Tomorrow's Date:%d%s %s\n",todayDay,
			(todayDay%10==1)?"st":
			(todayDay%10==2)?"nd":
			(todayDay%10==3)?"rd":
			"th",
			(todayMonth==January)?"January":
			(todayMonth==February)?"February":
			(todayMonth==March)?"March":
			(todayMonth==April)?"Apri;":
			(todayMonth==May)?"May":
			(todayMonth==June)?"June":
			(todayMonth==July)?"July":
			(todayMonth==August)?"August":
			(todayMonth==September)?"September":
			(todayMonth==October)?"October":
			(todayMonth==November)?"November":
			"December");

	}

}


int main(){
	enum Month mm=November;
	enum Day dd=TwentyFirst;
	printTomorrowDate(mm,dd);
}
