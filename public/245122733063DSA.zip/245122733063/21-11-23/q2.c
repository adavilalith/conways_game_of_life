#include<stdio.h>
#include<unistd.h>
enum trafficLight{red,yellow,green};

int main(){
	enum trafficLight l=red;
	while(1){
		switch(l){
			case red:
				printf("red\n");
				l=green;
				sleep(2);
			case green:
				printf("green\n");
				l=yellow;
				sleep(2);
			case yellow:
				printf("yellow\n");
				l=red;
				sleep(2);
		}

	}

}
