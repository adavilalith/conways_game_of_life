#include<stdio.h>
typedef struct{
	char city[20];
	char state[20];
	char country[20];
}address;
typedef struct{
	char rollno[20];
	char name[20];
	char dept[20];
	address loc;	
}student;
int main(){
	int n;
	printf("enter n:");
	scanf("%d",&n);
	student s[n];
	for(int i=0;i<n;i++){
		printf("enter name:");
		scanf("%s",s[i].name);
		printf("enter rollno:");
		scanf("%s",s[i].rollno);
		printf("enter department:");
		scanf("%s",s[i].dept);
		printf("enter city:");
		scanf("%s",s[i].loc.city);
		printf("enter state:");
		scanf("%s",s[i].loc.state);
		printf("enter country:");
		scanf("%s",s[i].loc.country);
	}
	for(int i=0;i<n;i++){
		printf("name:%s\n",s[i].name);
		printf("roll no:%s\n",s[i].rollno);
		printf("department:%s\n",s[i].dept);
		printf("adress:%s,%s,%s\n",s[i].loc.city,s[i].loc.state,s[i].loc.country);
	}
	return 0;
}



