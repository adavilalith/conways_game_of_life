#include<stdio.h>
#include<math.h>
typedef struct{
        int a;
        int b;
}compnum;
void read(compnum* num){
        printf("enter real and complex part of complex number:");
        scanf("%d %d",&num->a,&num->b);
}
void display(compnum num){
        printf("%d+%di\n",num.a,num.b);
}
compnum* compare(compnum* num1,compnum* num2){
        float m1,m2;
	m1=sqrt(pow(num1->a,2)+pow(num1->b,2));
	m2=sqrt(pow(num2->a,2)+pow(num2->b,2));
	if(m1>=m2){
		return num1;
	}
	else{
		return num2;
	}
}
int main(){
        compnum num1,num2;
        read(&num1);
        read(&num2);
        display(*compare(&num1,&num2));
        return 0;
}
