#include <stdio.h>
typedef struct{
	int a;
	int b;
}compnum;
void read(compnum* num){
	printf("enter real and complex part of complex number:");
	scanf("%d %d",&num->a,&num->b);
}
void display(compnum num){
	printf("%d+%di\n",num.a,num.b);
}
compnum add(compnum num1,compnum num2){
	compnum res;
	res.a=num1.a+num2.a;
	res.b=num1.b+num2.b;
	return res;
}
int main(){
	compnum num1,num2;
	read(&num1);
	read(&num2);
	display(add(num1,num2));
	return 0;
}
