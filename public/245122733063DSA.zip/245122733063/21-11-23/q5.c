#include<stdio.h>
#include<unistd.h>

typedef struct{
	int hour;
	int min;
	int sec;
}time;
void display(time clock){
	printf("%d:%d:%d\n",clock.hour,clock.min,clock.sec);
}
void increment(time* clock){
	clock->sec++;
	int carry=0;
	if(clock->sec>=60){
		carry=1;
		clock->sec=0;
	}
	clock->min+=carry;

	carry=0;
	if(clock->min>=60){
		carry=1;
		clock->min=0;
	}
	clock->hour+=carry;
}
int main(){
	time clock={1,0,0};
	while(1){
		display(clock);
		increment(&clock);
		sleep(1);
	}

}
